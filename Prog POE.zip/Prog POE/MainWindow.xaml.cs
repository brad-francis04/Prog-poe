﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace RecipeManagerGUI
{
    public partial class MainWindow : Window
    {
        private RecipeManager recipeManager;

        public MainWindow()
        {
            InitializeComponent();
            recipeManager = new RecipeManager();
        }

        private void btnAddRecipe_Click(object sender, RoutedEventArgs e)
        {
            AddRecipeWindow addRecipeWindow = new AddRecipeWindow(recipeManager);
            addRecipeWindow.ShowDialog();
            RefreshRecipeList();
        }

        private void btnDisplayRecipes_Click(object sender, RoutedEventArgs e)
        {
            RefreshRecipeList();
        }

        private void btnFilterRecipes_Click(object sender, RoutedEventArgs e)
        {
            FilterRecipesWindow filterRecipesWindow = new FilterRecipesWindow(recipeManager);
            filterRecipesWindow.ShowDialog();
        }

        private void RefreshRecipeList()
        {
            lstRecipes.ItemsSource = recipeManager.Recipes.Select(r => r.Name).ToList();
        }
    }
}
