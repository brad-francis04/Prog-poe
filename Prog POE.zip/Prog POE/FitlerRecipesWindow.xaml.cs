﻿using System.Linq;
using System.Windows;

namespace RecipeManagerGUI
{
    public partial class FilterRecipesWindow : Window
    {
        private RecipeManager recipeManager;

        public FilterRecipesWindow(RecipeManager manager)
        {
            InitializeComponent();
            recipeManager = manager;
        }

        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = txtIngredient.Text;
            string foodGroup = txtFoodGroup.Text;
            int maxCalories = int.TryParse(txtMaxCalories.Text, out int calories) ? calories : int.MaxValue;

            var filteredRecipes = recipeManager.Recipes.Where(r =>
                (string.IsNullOrEmpty(ingredient) || r.Ingredients.Any(i => i.Name.Contains(ingredient))) &&
                (string.IsNullOrEmpty(foodGroup) || r.Ingredients.Any(i => i.FoodGroup.Contains(foodGroup))) &&
                r.CalculateTotalCalories() <= maxCalories).Select(r => r.Name).ToList();

            lstFilteredRecipes.ItemsSource = filteredRecipes;
        }
    }
}
