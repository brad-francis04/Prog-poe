﻿using System.Windows;

namespace RecipeManagerGUI
{
    public partial class AddRecipeWindow : Window
    {
        private RecipeManager recipeManager;
        private Recipe recipe;

        public AddRecipeWindow(RecipeManager manager)
        {
            InitializeComponent();
            recipeManager = manager;
            recipe = new Recipe();
        }

        private void btnSaveRecipe_Click(object sender, RoutedEventArgs e)
        {
            recipe.Name = txtRecipeName.Text;

            int numIngredients = int.Parse(txtNumIngredients.Text);
            for (int i = 0; i < numIngredients; i++)
            {
                string[] ingredientData = txtIngredient.Text.Split(',');
                Ingredient ingredient = new Ingredient
                {
                    Name = ingredientData[0],
                    Quantity = double.Parse(ingredientData[1]),
                    Unit = ingredientData[2],
                    Calories = int.Parse(ingredientData[3]),
                    FoodGroup = ingredientData[4]
                };
                recipe.Ingredients.Add(ingredient);
            }

            int numSteps = int.Parse(txtNumSteps.Text);
            for (int i = 0; i < numSteps; i++)
            {
                recipe.Steps.Add(txtStep.Text);
            }

            recipeManager.AddRecipe(recipe);
            MessageBox.Show("Recipe added successfully!");
            Close();
        }
    }
}
